__author__="Nikhil Rayaprolu"
__version__ = "1.0.0"
__maintainer__ = "Nikhil Rayaprolu"
__email__ = "nikhil.rayaprolu@students.iiit.ac.in"
__status__ = "Development"

import random,time,pygame,sys
from pygame.locals import *
from gameplay import GamePlay
if __name__=="__main__":
    	#Initialising pygame display 
		
		GamePlay=GamePlay()
		GamePlay.start()
		#Setting caption for window
		
